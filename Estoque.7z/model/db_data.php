<?php


	//Variáveis de de configuração do banco de dados.
	$GLOBALS['db_host'] = "localhost";
	$GLOBALS['db_user'] = "root";
	$GLOBALS['db_password'] = "senha";
	$GLOBALS['db_name'] = "database_name";

?>