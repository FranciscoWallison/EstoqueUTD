<?php
	$GLOBALS['dictionary'] = array(
		'user_not_found' => "Usuário não encontrado",
		'password_incorrect' => "Senha Incorreta",
		'user_inative' => "Conta Inativa",
		'permission_denied' => "Permissão negada",
		'logout'=> "Você foi Desconectado",
		'user_updated'=>"Seus dados foram atualizados",
		'category_created' => "Categoria criada",
		'user_created' => "Novo usuário criado",
		'product_created' => "Novo produto criado",
		'product_deleted' => "Produto Excluído",
		'category_deleted' => "Categoria Excluído",
		'user_deleted' => "Usuário Excluído",
		'product_updated' => "Produto Atualizado",
		'category_updated' => "Categoria Atualizada",
	);
?>